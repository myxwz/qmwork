package com.example.myapplication005.adapter;

public class ImagePagerAdapater {
}
